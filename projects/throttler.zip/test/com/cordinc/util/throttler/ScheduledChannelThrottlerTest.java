package com.cordinc.util.throttler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.jmock.lib.concurrent.DeterministicScheduler;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("serial")
public class ScheduledChannelThrottlerTest {
	
	private static final String CHANNEL1 = "CHANNEL1";
	private static final String CHANNEL2 = "CHANNEL2";
	private DeterministicScheduler scheduler;
	private AtomicLong currentTime = new AtomicLong(0);
	private ScheduledChannelThrottler throttler;
	private AtomicInteger count = new AtomicInteger(0);
	private Runnable countIncrementTask = new Runnable() {@Override public void run() {count.incrementAndGet();}};
	
	@Before public void setupThrottler() {
		scheduler = new DeterministicScheduler();
		currentTime.set(0);	
		Map<Object, Rate> channels = new HashMap<Object, Rate>() {{
			put(CHANNEL1, new Rate(3, 1, TimeUnit.SECONDS));
			put(CHANNEL2, new Rate(1, 1, TimeUnit.SECONDS));
		}};
		throttler = new ScheduledChannelThrottler(new Rate(2, 1, TimeUnit.SECONDS), scheduler, channels, new TimeProvider() {
			@Override public long getCurrentTimeInMillis() {return currentTime.get();}		
		});
		count = new AtomicInteger(0);
	}	
	
	@Test public void testTotalChannelWithNoDelay() throws Exception {
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
	}
	
	@Test public void testTotalChannelWithDelay() throws Exception {
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(1000, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
	}
	
	@Test public void testTotalChannelWithDoubleDelay() throws Exception {
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(500, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(500, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
		scheduler.tick(1000, TimeUnit.MILLISECONDS);
		assertEquals(5, count.get());
	}
	
	@Test public void testTotalChannelWithShortestDelay() throws Exception {
		throttler.submit(countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(countIncrementTask);
		throttler.submit(countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(countIncrementTask);
		
		assertEquals(2, count.get());
		scheduler.tick(124, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
	}
	
	@Test public void testChannel() throws Exception {
		throttler.submit(CHANNEL2, countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		
		assertEquals(1, count.get());
		scheduler.tick(124, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(1000, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
	}
	
	@Test public void testChannelAndTotal() throws Exception {
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL1, countIncrementTask);
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL1, countIncrementTask);
		
		assertEquals(2, count.get());
		scheduler.tick(124, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
	}
	
	@Test public void testChannelAffectsTotal() throws Exception {
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL1, countIncrementTask);
		throttler.submit(countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL1, countIncrementTask);
		
		assertEquals(2, count.get());
		scheduler.tick(124, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
	}
	
	private class OrderedTask implements Runnable {
		private final int order;
		public OrderedTask(int order) {this.order=order;}
		@Override public void run() {
			assertEquals(count.incrementAndGet(), order);
		}
	};
	
	@Test public void testChannelCallsAreOrdered() throws Exception {
		throttler.submit(CHANNEL1, new OrderedTask(1));
		throttler.submit(CHANNEL2, new OrderedTask(2));
		throttler.submit(CHANNEL1, new OrderedTask(3));
		throttler.submit(CHANNEL2, new OrderedTask(4));
		throttler.submit(CHANNEL2, new OrderedTask(5));
		throttler.submit(CHANNEL1, new OrderedTask(6));
		throttler.submit(CHANNEL1, new OrderedTask(7));
		scheduler.tick(5000, TimeUnit.MILLISECONDS);
		assertEquals(7, count.get());
	}
	
	@Test public void testMultiChannel() throws Exception {
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(CHANNEL1, countIncrementTask);
		throttler.submit(CHANNEL1, countIncrementTask);
		
		assertEquals(2, count.get());
		scheduler.tick(123, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(778, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
		scheduler.tick(1001, TimeUnit.MILLISECONDS);
		assertEquals(6, count.get());
		scheduler.tick(999, TimeUnit.MILLISECONDS);
		assertEquals(6, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(7, count.get());
	}
	
	@Test public void testMultiChannelWithTotal() throws Exception {
		throttler.submit(CHANNEL1, countIncrementTask);
		currentTime = new AtomicLong(777);	
		scheduler.tick(777, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(countIncrementTask);
		currentTime = new AtomicLong(877);
		scheduler.tick(100, TimeUnit.MILLISECONDS);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(CHANNEL2, countIncrementTask);
		throttler.submit(countIncrementTask);
		throttler.submit(CHANNEL1, countIncrementTask);
		
		assertEquals(2, count.get());
		scheduler.tick(123, TimeUnit.MILLISECONDS);
		assertEquals(2, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(3, count.get());
		scheduler.tick(778, TimeUnit.MILLISECONDS);
		assertEquals(4, count.get());
		scheduler.tick(1001, TimeUnit.MILLISECONDS);
		assertEquals(6, count.get());
		scheduler.tick(999, TimeUnit.MILLISECONDS);
		assertEquals(6, count.get());
		scheduler.tick(1, TimeUnit.MILLISECONDS);
		assertEquals(7, count.get());
	}
	
	@Test public void testSync() throws Exception {
		Map<Object, Rate> channels = new HashMap<Object, Rate>() {{
			put(CHANNEL1, new Rate(3, 250, TimeUnit.MILLISECONDS));
			put(CHANNEL2, new Rate(1, 250, TimeUnit.MILLISECONDS));
		}};
		throttler = new ScheduledChannelThrottler(new Rate(2, 250, TimeUnit.MILLISECONDS), channels);
		
		long start = System.nanoTime()/1000000;
		throttler.submitSync(CHANNEL2, countIncrementTask);
		assertEquals(1, count.get());
		long call1 = System.nanoTime()/1000000;
		assertTrue(call1-start<32);
		
		throttler.submitSync(CHANNEL2, countIncrementTask);
		assertEquals(2, count.get());
		long call2 = System.nanoTime()/1000000;
		assertTrue(call2-call1>200 && call2-call1<300);
		
		throttler.submitSync(CHANNEL2, countIncrementTask);
		assertEquals(3, count.get());
		long call3 = System.nanoTime()/1000000;
		assertTrue(call3-call2>200 && call3-call2<300);
	}
	
	@Test
	public void scheduledTasksMonotonicallyIncreasing(){
		int numCalls = 50;
		int totalCalls = 1000;
		int ratePeriod = 100;
		final CountDownLatch latch = new CountDownLatch(totalCalls);
		Rate rate = new Rate(numCalls, ratePeriod, TimeUnit.MILLISECONDS);
		ScheduledChannelThrottler throttler = new ScheduledChannelThrottler(rate);
		final ConcurrentLinkedQueue<Long> base = new ConcurrentLinkedQueue<Long>();
		
		for(int i = 0; i < totalCalls; i++) {
			throttler.submit(new Runnable() {
				@Override public void run() {
					base.add(System.currentTimeMillis());
					latch.countDown();
				}			
			});
		}
	
		// wait for the tasks to finish, before exiting
		try {
			latch.await((totalCalls/numCalls)*ratePeriod, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			fail();
		}

		assertEquals(base.size(), 1000);
		long last = 0;
		for (Long next: base) {
			assertTrue(next >= last);
			last = next;
		}
	}
	
	public class RunnableImpl implements Runnable {
		private final int id;
		private final ConcurrentLinkedQueue<Integer> collection;
		private final CountDownLatch latch;
		
		public RunnableImpl(int id, ConcurrentLinkedQueue<Integer> collection, CountDownLatch latch) {
			this.id = id;
			this.collection = collection;
			this.latch = latch;
		}
		
		public void run() {
			collection.add(id);
			latch.countDown();
		}
	}
}
