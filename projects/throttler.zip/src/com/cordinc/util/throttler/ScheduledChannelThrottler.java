package com.cordinc.util.throttler;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Millisecond accuracy
 * does not maintains order of calls (thus have to start from back rather than try to insert things in middle)
 */
public final class ScheduledChannelThrottler extends AbstractChannelThrottler {
	
	public ScheduledChannelThrottler(Rate totalRate) {
		this(totalRate, Executors.newSingleThreadScheduledExecutor(), new HashMap<Object, Rate>(), TimeProvider.SYSTEM_PROVIDER);
	}
	
	public ScheduledChannelThrottler(Rate totalRate, Map<Object, Rate> channels) {
		this(totalRate, Executors.newSingleThreadScheduledExecutor(), channels, TimeProvider.SYSTEM_PROVIDER);
	}
	
	public ScheduledChannelThrottler(Rate totalRate, ScheduledExecutorService scheduler, Map<Object, Rate> channels, TimeProvider timeProvider) {
		super(totalRate, scheduler, channels, timeProvider);
	}	
		
	public void submitSync(Object channelKey, Runnable task) throws InterruptedException {
		Thread.sleep(getThrottleDelay(channelKey)); 
		task.run();
	}
	
	public void submitSync(Runnable task) throws InterruptedException {
		long delay = callTime(null)-timeProvider.getCurrentTimeInMillis();
		Thread.sleep(getThrottleDelay(delay)); 
		task.run();
	}
	
	@Override public Future<?> submit(Runnable task) {
		long delay = callTime(null)-timeProvider.getCurrentTimeInMillis();
		return scheduler.schedule(task, delay<0?0:delay, TimeUnit.MILLISECONDS);
	} 
	
	@Override public Future<?> submit(Object channelKey, Runnable task) {
		return scheduler.schedule(task, getThrottleDelay(channelKey), TimeUnit.MILLISECONDS);
	} 
}
