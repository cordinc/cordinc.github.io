package com.cordinc.util.throttler;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Millisecond accuracy
 * maintains order of calls 
 */
public final class QueueChannelThrottler extends AbstractChannelThrottler {
	
	private final Runnable processQueueTask = new Runnable() {
		@Override public void run() {
			FutureTask<?> task = tasks.poll();
			if (task!=null && !task.isCancelled()) {
				task.run();
			}
		}		
	};
	private final Queue<FutureTask<?>> tasks = new LinkedList<FutureTask<?>>();

	public QueueChannelThrottler(Rate totalRate) {
		this(totalRate, Executors.newSingleThreadScheduledExecutor(), new HashMap<Object, Rate>(), TimeProvider.SYSTEM_PROVIDER);
	}
	
	public QueueChannelThrottler(Rate totalRate, Map<Object, Rate> channels) {
		this(totalRate, Executors.newSingleThreadScheduledExecutor(), channels, TimeProvider.SYSTEM_PROVIDER);
	}
	
	public QueueChannelThrottler(Rate totalRate, ScheduledExecutorService scheduler, Map<Object, Rate> channels, TimeProvider timeProvider) {
		super(totalRate, scheduler, channels, timeProvider);
	}
	
	@Override public Future<?> submit(Runnable task) {
		return submit(null, task);
	} 
	
	@SuppressWarnings("unchecked")
	@Override public Future<?> submit(Object channelKey, Runnable task) {
		long throttledTime = channelKey==null?callTime(null):callTime(channels.get(channelKey));
		FutureTask runTask = new FutureTask(task, null);
		tasks.add(runTask);
		long now = timeProvider.getCurrentTimeInMillis();
		scheduler.schedule(processQueueTask, throttledTime<now?0:throttledTime-now, TimeUnit.MILLISECONDS);
		return runTask;
	} 

}
