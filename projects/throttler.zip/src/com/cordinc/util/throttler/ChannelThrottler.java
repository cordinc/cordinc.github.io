package com.cordinc.util.throttler;

import java.util.concurrent.Future;

public interface ChannelThrottler {
	Future<?> submit(Runnable task);
	Future<?> submit(Object channelKey, Runnable task);
}
