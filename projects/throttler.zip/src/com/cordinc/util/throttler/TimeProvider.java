package com.cordinc.util.throttler;

public interface TimeProvider {
	public static final TimeProvider SYSTEM_PROVIDER = new TimeProvider() {
		@Override public long getCurrentTimeInMillis() {return System.currentTimeMillis();}
	};
	
	public long getCurrentTimeInMillis();
}
