package com.cordinc.intrade.model;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class AllTests extends TestCase {
	
	public AllTests(String name) {
      super(name);
   }
  
   public static Test suite() {
      TestSuite suite= new TestSuite(); 
      suite.addTest(new TestSuite(EventTest.class));
      suite.addTest(new TestSuite(ContractTest.class));
      suite.addTest(new TestSuite(ContractDepthTest.class));
      return suite;
   }
}
