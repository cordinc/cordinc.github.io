package com.cordinc.intrade.model;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ContractTest extends TestCase {
	
	private Contract contract1, contract2;
	   	   
   public ContractTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(ContractTest.class);
   }
   
   protected void setUp() {
	   contract1 = new Contract("id1", "name1", ContractState.OPEN, 0.1);
	   contract2 = new Contract("id2", "name2", ContractState.OPEN, 0.1);
   }  
	
	public void testStandard() {
	  assertTrue(contract1.equals(new Contract("id1", "name1", ContractState.OPEN, 0.1)));
      assertFalse(contract1.equals(contract2)); 
      assertFalse(contract1.equals("aa"));      
      assertEquals("id1".hashCode(), contract1.hashCode());
      assertEquals(new Contract("id1", "name1", ContractState.OPEN, 0.1).hashCode(),contract1.hashCode());	
      assertEquals(contract1.toString(), contract1.getName());
   }
	
	public void testDepth() {
		assertNull(contract1.getAskDepth(1));
		contract1.putDepth(Side.ASK, 1, 95, 10);
		assertEquals(contract1.getAskDepth(1), new ContractDepth(Side.ASK, 1, 95, 10, 0.1));
		contract2.putDepth(Side.BID, 3, 85, 11);
		assertEquals(contract2.getBidDepth(3), new ContractDepth(Side.BID, 3, 85, 11, 0.1));
		assertNull(contract2.getBidDepth(1));
	}

}
