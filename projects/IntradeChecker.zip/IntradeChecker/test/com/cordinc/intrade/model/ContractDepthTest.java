package com.cordinc.intrade.model;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ContractDepthTest extends TestCase {
	
	private ContractDepth depth1, depth2;
	   	   
   public ContractDepthTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(ContractDepthTest.class);
   }
   
   protected void setUp() {
	   depth1 = new ContractDepth(Side.ASK, 1, 795, 10, 0.1);
	   depth2 = new ContractDepth(Side.BID, 1, 25, 10, 0.1);
   }  
	
	public void testStandard() {
	  assertTrue(depth1.equals(new ContractDepth(Side.ASK, 1, 795, 10, 0.1)));
      assertFalse(depth1.equals(depth2)); 
      assertFalse(depth1.equals("aa"));      
      assertEquals(new ContractDepth(Side.ASK, 1, 795, 10, 0.1).hashCode(),depth1.hashCode());	   
   }
	
	public void testCalcs() {
		assertEquals(depth1.price(), 79.5);
		assertEquals(depth2.price(), 2.5);
		assertEquals(depth1.grossProfit(), 20.5);
		assertEquals(depth2.grossProfit(), 2.5);
		assertEquals(depth1.netProfit(), 19.1);
		assertEquals(depth2.netProfit(), 1.2);
		
		assertTrue(Math.abs(depth1.implicitRate(365) - 0.23) < 0.01);
		assertTrue(Math.abs(depth2.implicitRate(1) - 8.32) < 0.01);
		assertTrue(Math.abs(new ContractDepth(Side.ASK, 1, 995, 10, 0.1).implicitRate(1) - -0.77) < 0.01);
		
	}

}
