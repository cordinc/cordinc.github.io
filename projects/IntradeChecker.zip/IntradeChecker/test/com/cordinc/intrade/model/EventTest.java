package com.cordinc.intrade.model;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class EventTest extends TestCase {
	
	private static final long DAY_MS = 24l*60l*60l*1000l;
	private Event event1, event2;
	   	   
   public EventTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(EventTest.class);
   }
   
   protected void setUp() {
	   event1 = new Event("id", "name", "group", new Date(System.currentTimeMillis() + (3*DAY_MS)));
	   event2 = new Event("id2", "name2", null, new Date(System.currentTimeMillis() + (2*DAY_MS)));
   }  
   
   public void testContract() {
	   Collection<Contract> c = Arrays.asList(new Contract("id", "name", ContractState.OPEN, 0.1));
	   event1.addContracts(c);
	   assertEquals(event1.getContracts().size(), 1);
	   assertNotSame(event1.getContracts(), c);
   }
   
   public void testStandard() {
	  assertTrue(event1.equals(new Event("id", "name2", "group2", new Date(System.currentTimeMillis() + (2*DAY_MS)))));
      assertFalse(event1.equals(event2)); 
      assertFalse(event1.equals("aa"));      
      assertEquals("id".hashCode(), event1.hashCode());
      assertEquals(new Event("id", "name2", "group2", new Date(System.currentTimeMillis() + (2*DAY_MS))).hashCode(),event1.hashCode());	   
   }
   
   // test the equals function
   public void testDaysRemaining() {
	   assertEquals(event1.daysRemaining(), 3); 
	   assertEquals(event2.daysRemaining(), 2);
	   assertEquals(new Event("id", "name2", "group2", new Date(System.currentTimeMillis())).daysRemaining(), 0);
	   assertEquals(new Event("id", "name2", "group2", new Date(System.currentTimeMillis() + (-2*DAY_MS))).daysRemaining(), -2);
   }
   
// test the equals function
   public void testDescription() {
	   assertEquals(event1.getDescription(), event1.toString());
	   assertEquals(event1.getDescription(), "group: name");
	   assertEquals(event2.getDescription(), "name2");
   }

}
