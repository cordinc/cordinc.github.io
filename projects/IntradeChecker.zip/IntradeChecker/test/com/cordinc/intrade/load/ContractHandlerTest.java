package com.cordinc.intrade.load;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Date;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.Event;

public class ContractHandlerTest extends TestCase {
	   
   public ContractHandlerTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(ContractHandlerTest.class);
   }
   
   protected void setUp() {
   }  
   
   public void testAll() {
	   Collection<Event> events = load(new ShortOpenFilter(new Date(Long.MAX_VALUE)));
	   assertEquals(events.size(), 13);
	   
	   events = load(null);
	   assertEquals(events.size(), 13);
	   for (Event e: events) {
		   if (e.getId().equals("76896")) {
			   assertEquals(e.getDescription(), "Climate Change: China and India - acceptance of CO2 emissions limits");
			   assertEquals(e.getContracts().size(), 2);
			   for (Contract c: e.getContracts()) {
				   if (c.getId().equals("554014")) {
					   assertEquals(c.getName(), "India agrees before end of 2009 to binding target limiting CO2 emissions");
					   assertEquals(c.getTickSize(), 0.1);
					   return;
				   }
			   }
			   fail();
		   }
	   }
	   fail();
   }
   
   private Collection<Event> load(LoadFilter filter) {
	   InputStream input = null;
	   ContractHandler handler = new ContractHandler(filter);
	   try {   			         	
           SAXParserFactory factory = SAXParserFactory.newInstance();
           SAXParser saxParser = factory.newSAXParser();
           input = ClassLoader.getSystemResourceAsStream("com/cordinc/intrade/load/contracts.xml");               
           saxParser.parse(input, handler); 	               	            
           saxParser.reset();
       } catch (Exception ex) {
       		System.err.println("Depth load: "+ex);
       } finally {
       		try {input.close();} catch (IOException ex) {/* ignore */}
       }
       
       return handler.getEvents();
   }

}