package com.cordinc.intrade.load;

import java.util.Date;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.ContractState;
import com.cordinc.intrade.model.Event;

public class ShortOpenFilterTest extends TestCase {
	
	private static final long DAY_MS = 24l*60l*60l*1000l;
	   	   
   public ShortOpenFilterTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(ShortOpenFilterTest.class);
   }
   
   protected void setUp() {
   }  
   
   public void testAll() {
	   ShortOpenFilter f1 = new ShortOpenFilter(new Date(System.currentTimeMillis() + (3*DAY_MS)));
	   ShortOpenFilter f2 = new ShortOpenFilter(new Date(System.currentTimeMillis() + (10*DAY_MS)));
	   
	   assertTrue(f1.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (2*DAY_MS)))));
	   assertTrue(f2.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (2*DAY_MS)))));
	   assertFalse(f1.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (5*DAY_MS)))));
	   assertTrue(f2.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (5*DAY_MS)))));	   
	   assertFalse(f1.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (11*DAY_MS)))));
	   assertFalse(f2.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (11*DAY_MS)))));
	   assertFalse(f1.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (-1*DAY_MS)))));
	   assertFalse(f2.loadEvent(new Event("", "", "", new Date(System.currentTimeMillis() + (-1*DAY_MS)))));
	   assertTrue(f1.loadContract(new Contract("", "", ContractState.OPEN, 0)));
	   assertTrue(f2.loadContract(new Contract("", "", ContractState.OPEN, 0)));	   
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.CANCELLED, 0)));
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.EXPIRY, 0)));
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.PAUSED, 0)));
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.REVERSED, 0)));
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.SETTLED, 0)));
	   assertFalse(f2.loadContract(new Contract("", "", ContractState.CLOSED, 0)));
   }

}
