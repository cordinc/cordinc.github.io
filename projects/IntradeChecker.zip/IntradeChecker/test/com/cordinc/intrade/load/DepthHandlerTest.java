package com.cordinc.intrade.load;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.ContractState;

public class DepthHandlerTest extends TestCase {
	   
   public DepthHandlerTest(String name) {
      super(name);
   }
  
   public static Test suite() {
      return new TestSuite(DepthHandlerTest.class);
   }
   
   protected void setUp() {
   }  
   
   public void testAll() {
	   Contract c = load("com/cordinc/intrade/load/depth1.xml");
	   assertNotNull(c.getAskDepth(0));
	   assertEquals(c.getAskDepth(1).getQuantity(), 275);
	   assertNull(c.getBidDepth(0));
	   
	   c = load("com/cordinc/intrade/load/depth2.xml");
	   assertEquals(c.getBidDepth(2).getPriceTicks(), 10);
	   assertEquals(c.getAskDepth(4).getQuantity(), 29);
	   
	   c = load("com/cordinc/intrade/load/depth3.xml");
	   assertNull(c.getBidDepth(0));
	   assertNull(c.getAskDepth(0));
   }
	
   private Contract load(String fileName) {
	   Contract c = new Contract("", "", ContractState.OPEN, 0.1);
	   InputStream input = null;	
	   try {   			         	
           SAXParserFactory factory = SAXParserFactory.newInstance();
           SAXParser saxParser = factory.newSAXParser();
           input = ClassLoader.getSystemResourceAsStream(fileName);               
           saxParser.parse(input, new DepthHandler(c)); 	               	            
           saxParser.reset();
       } catch (Exception ex) {
       		System.err.println("Depth load: "+ex);
       } finally {
       		try {input.close();} catch (IOException ex) {/* ignore */}
       }
       return c;
   }

}
