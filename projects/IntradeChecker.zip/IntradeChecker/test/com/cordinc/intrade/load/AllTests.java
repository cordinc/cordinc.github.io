package com.cordinc.intrade.load;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class AllTests extends TestCase {
	
	public AllTests(String name) {
      super(name);
   }
  
   public static Test suite() {
      TestSuite suite= new TestSuite(); 
      suite.addTest(new TestSuite(DepthHandlerTest.class));
      suite.addTest(new TestSuite(ContractHandlerTest.class));
      suite.addTest(new TestSuite(ShortOpenFilterTest.class));
      return suite;
   }
}
