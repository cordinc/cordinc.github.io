// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.load;

import java.util.Date;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.ContractState;
import com.cordinc.intrade.model.Event;

/**
 * A filter that only allows events that expire before the given date and only their open contracts.
 * 
 * @author cordinc
 */
public class ShortOpenFilter implements LoadFilter {
	
	private final Date shortDate;
	private final Date today;
	
	/**
	 * Constructs a filter that only allows events that expire before the given date and only their open contracts.
	 * @param shortDate the date by which allowed events must expire
	 */
	public ShortOpenFilter(Date shortDate) {
		this.shortDate = shortDate; 
		today = new Date();
	}
	
	/**
	 * Returns true if and only if the given event expires no later than the date given in the constructor.
	 * @param event the event to examine
	 * @return true if and only if the given event expires no later than the date given in the constructor.
	 */
	public boolean loadEvent(Event event) {
		return event.getEndDate().before(shortDate) && event.getEndDate().after(today);
	}
	
	/**
	 * Returns true if and only if the given contract is open.
	 * @param contract the contract to examine
	 * @return true if and only if the given contract is open.
	 */
	public boolean loadContract(Contract contract) {
		return ContractState.OPEN == contract.getState();
	}

}
