// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.load;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collection;
import java.util.Date;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.Event;

/**
 * Loads the events from Intrade complete with contract depth.
 * 
 * @author cordinc
 */
public class EventLoader {
	
	private static final long DAY_MS = 24l*60l*60l*1000l;
	
	/**
	 * Loads and returns directly from Intrade's website the events with at most the given number of 
	 * days to expiry and only their open contracts.
	 * 
	 * @param remainingDays the maximum number of days until expiry
	 * @return the events from Intrade's website.
	 */
	public Collection<Event> get(int remainingDays) {
		InputStream input = null;		
		Date filter = new Date(System.currentTimeMillis() + (remainingDays*DAY_MS));
		ContractHandler handler = new ContractHandler(new ShortOpenFilter(filter));
		try {
            URL contractsUrl = new URL("http://www.intrade.com/jsp/XML/MarketData/xml.jsp");
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            input = contractsUrl.openStream();           
            saxParser.parse(input, handler); 
            saxParser.reset();
        } catch (Exception e) {
        	System.err.println("Main load: "+e);
        } finally {
        	try {input.close();} catch (IOException e) {/* ignore */}
        }
        
        Collection<Event> events = handler.getEvents();
        for (Event e: events) {
        	for (Contract c: e.getContracts()) {
	    		try {   			
	                URL depthUrl = new URL("http://www.intrade.com/jsp/XML/MarketData/ContractBookXML.jsp?id="+c.getId());	
	                SAXParserFactory factory = SAXParserFactory.newInstance();
	                SAXParser saxParser = factory.newSAXParser();
	                input = depthUrl.openStream();	                
	                saxParser.parse(input, new DepthHandler(c)); 	               	            
	                saxParser.reset();
	            } catch (Exception ex) {
	            	System.err.println("Depth load: "+ex);
	            } finally {
	            	try {input.close();} catch (IOException ex) {/* ignore */}
	            }
        	}
        }
        return events;
	}

}
