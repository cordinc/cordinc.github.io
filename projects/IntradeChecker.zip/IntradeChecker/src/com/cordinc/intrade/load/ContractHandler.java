// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.load;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.ContractState;
import com.cordinc.intrade.model.Event;

/**
 * SAX handler to parse an Intrade events and expose a collection of the results.
 * 
 * @author cordinc
 */
public class ContractHandler extends DefaultHandler {
	
	private Date endDate;
	private double tickSize;
	private String contractId, eventId;
	private ContractState state;
	private String contractName, eventName, groupName;
	private StringBuffer textBuffer = new StringBuffer();	
	private boolean inContract = false, inEvent = false, inGroup = false;
	private boolean readBuffer = false;
	private Collection<Contract> contracts = new ArrayList<Contract>();
	private Collection<Event> events = new ArrayList<Event>();
	private final LoadFilter filter;
	
	/**
	 * Construct a handler to create events from Intrade, skipping some according to the provided filter. 
	 * If the filter is null all events and contracts will be provided.
	 * @param filter the filter to use when deciding to skip events.
	 */
	public ContractHandler(LoadFilter filter) {
		this.filter = filter;
	}
	
	/**
	 * Returns the events parsed by this handler.
	 * @return the events parsed by this handler.
	 */
	public Collection<Event> getEvents() {
		return events;
	}
	
	/**
	 * SAX method - unavoidably expose, but should never be called directly except by SAX parser
	 */
	public void startElement(String namespaceURI, String sName, String qName, Attributes attrs) throws SAXException {
		String elementName = getElementName(sName, qName);
		if ("EventGroup".equalsIgnoreCase(elementName)) {
			inGroup = true;
			groupName = null;
		} else if ("Event".equalsIgnoreCase(elementName)) {
			endDate = new Date(Long.parseLong(attrs.getValue("EndDate")));
			eventId = attrs.getValue("id");
			inEvent = true;
		} else if (endDate!=null && "Contract".equalsIgnoreCase(elementName)) {
			inContract = true;
			contractId = attrs.getValue("id");
			String raw = attrs.getValue("tickSize");
			if (raw!=null) {
				tickSize = Double.parseDouble(raw);
        	} else {
        		tickSize = 0.1;
        	}			 
			state = ContractState.parseCode(attrs.getValue("state"));
		} else if ((inContract || inEvent || inGroup) && "name".equalsIgnoreCase(elementName)) {
			readBuffer = true;
		} 
	}
	
	/**
	 * SAX method - unavoidably expose, but should never be called directly except by SAX parser
	 */
	public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
		String elementName = getElementName(sName, qName);
		if ("EventGroup".equalsIgnoreCase(elementName)) {
			inGroup = false;
		} else if ("Event".equalsIgnoreCase(elementName)) {
			inEvent = false;		
			Event e = new Event(eventId, eventName, groupName, endDate);
			if ((filter==null || filter.loadEvent(e)) && !contracts.isEmpty()) {
				e.addContracts(contracts);
				events.add(e);
			}
			contracts.clear();
			endDate = null;
		} else if ("Contract".equalsIgnoreCase(elementName)) {
			inContract = false;
			Contract c = new Contract(contractId, contractName, state, tickSize);
			if (filter==null || filter.loadContract(c)) {
				contracts.add(c);
			}
		} else if ("name".equalsIgnoreCase(elementName)) {
			if (inContract) {
				readBuffer = false;
				contractName = textBuffer.toString();
				textBuffer = new StringBuffer();
			} else if (inEvent) {
				readBuffer = false;
				eventName = textBuffer.toString();
				textBuffer = new StringBuffer();
			} else if (inGroup) {
				readBuffer = false;
				groupName = textBuffer.toString();
				textBuffer = new StringBuffer();
			}
		} 
	} 
	
	/**
	 * SAX method - unavoidably expose, but should never be called directly except by SAX parser 
	 */
	public void characters(char buf[], int offset, int len) throws SAXException {
		if (readBuffer) {
			textBuffer.append(new String(buf, offset, len));
		}
	} 

	private String getElementName(String sName, String qName) {
		return ("".equals(sName))?qName:sName; 
	}
}
