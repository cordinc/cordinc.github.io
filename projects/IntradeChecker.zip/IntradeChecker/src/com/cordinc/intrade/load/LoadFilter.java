// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.load;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.Event;

/**
 * This defines the rules which allows certain events and contracts to be skipped when loading them from Intrade.
 * 
 * @author cordinc
 */
public interface LoadFilter {
	/**
	 * Returns true if and only if the given event should be loaded.
	 * @param event the event to examine
	 * @return true if and only if the given event should be loaded.
	 */
	public boolean loadEvent(Event event);
	
	/**
	 * Returns true if and only if the given contract should be loaded.
	 * @param contract the contract to examine
	 * @return true if and only if the given contract should be loaded.
	 */
	public boolean loadContract(Contract contract);
}
