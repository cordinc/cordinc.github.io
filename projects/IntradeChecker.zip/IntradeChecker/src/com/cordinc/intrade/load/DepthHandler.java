// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.load;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.Side;

/**
 * SAX handler to parse an Intrade contract depth message and update a contract with the result.
 * 
 * @author cordinc
 */
public class DepthHandler extends DefaultHandler {
	
	private final Contract contract;
	private int askLevel, bidLevel;
	
	/**
	 * Construct a handler to update the given contract with the depth from Intrade
	 * @param contract the contract which will have its depth updated.
	 */
	public DepthHandler(Contract contract) {
		this.contract = contract;
	}
	
	/**
	 * SAX method - unavoidably expose, but should never be called directly except by SAX parser
	 */
	public void startElement(String namespaceURI, String sName, String qName, Attributes attrs) throws SAXException {
		String elementName = getElementName(sName, qName);
		if ("bid".equalsIgnoreCase(elementName)) {
			int priceTicks = (int)Math.round(Double.parseDouble(attrs.getValue("price"))/contract.getTickSize());			
			contract.putDepth(Side.BID, bidLevel++, priceTicks, Integer.parseInt(attrs.getValue("quantity")));
		} else if ("offer".equalsIgnoreCase(elementName)) {
			int priceTicks = (int)Math.round(Double.parseDouble(attrs.getValue("price"))/contract.getTickSize());			
			contract.putDepth(Side.ASK, askLevel++, priceTicks, Integer.parseInt(attrs.getValue("quantity")));
		} 
	}
	
	private String getElementName(String sName, String qName) {
		return ("".equals(sName))?qName:sName; 
	}
}
