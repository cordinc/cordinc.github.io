// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Model class represent an Intrade Contract.
 * 
 * @author cordinc
 */
public class Contract {
	private final ContractState state;
	private final String id;
	private final String name;
	private final double tickSize;
	private final Map<Integer, ContractDepth> bids = new LinkedHashMap<Integer, ContractDepth>();
	private final Map<Integer, ContractDepth> asks = new LinkedHashMap<Integer, ContractDepth>();
	private final ReadWriteLock lock = new ReentrantReadWriteLock();

	/**
	 * Construct the Intrade Contract.
	 * @param id the Intrade id code of this contract.
	 * @param name the description of this contract.
	 * @param state the state of this contract.
	 * @param tickSize the size of a price tick on this contract.
	 */
	public Contract(String id, String name, ContractState state, double tickSize) {
		this.id = id;
		this.name = name;
		this.state = state;
		this.tickSize = tickSize;
	}
	
	/**
	 * Add an aggregated quote to this contract with the specified parameters.
	 * @param side the side of the quote
	 * @param level the level of the quote, that is it is the level'th best quote on the given side. 0 is the best quote.
	 * @param priceTicks the number of price ticks in the price.
	 * @param quantity the quantity being offered at this price and side.
	 */
	public void putDepth(Side side, int level, int priceTicks, int quantity) {
		ContractDepth depth = new ContractDepth(side, level, priceTicks, quantity, tickSize);
		lock.writeLock().lock();		
		if (depth.getSide() == Side.ASK) {
			asks.put(depth.getLevel(), depth);
		} else if (depth.getSide() == Side.BID) {
			bids.put(depth.getLevel(), depth);
		}
		lock.writeLock().unlock();
	}
	
	/**
	 * Returns the level'th best ask quote on this contract. Level 0 is the best quote. Returns null if there
	 * is no quote at the given level.
	 * @param level the level of the depth to return.
	 * @return the level'th best ask quote on this contract.
	 */
	public ContractDepth getAskDepth(int level) {
		lock.readLock().lock();
		ContractDepth depth = asks.get(level);
		lock.readLock().unlock();
		return depth;
	}
	
	/**
	 * Returns the level'th best bid quote on this contract. Level 0 is the best quote. Returns null if there
	 * is no quote at the given level.
	 * @param level the level of the depth to return.
	 * @return the level'th best bid quote on this contract.
	 */
	public ContractDepth getBidDepth(int level) {
		lock.readLock().lock();
		ContractDepth depth = bids.get(level);
		lock.readLock().unlock();
		return depth;
	}

	/**
	 * Returns the size of a price tick in this contract.
	 * @return the size of a price tick.
	 */
	public double getTickSize() {
		return tickSize;
	}

	/**
	 * Returns the state of the contract.
	 * @return the state of the contract.
	 */
	public ContractState getState() {
		return state;
	}

	/**
	 * Returns the id code of this contract.
	 * @return the id code of this contract.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Returns the name (or description) of the contract.
	 * @return the name (or description) of the contract.
	 */
	public String getName() {
		return name;
	}
	
	/**
     * Compares this Contract to the specified object for equality. The result
     * is true if and only if the argument is not null and is a Contract object
     * that has the same id as this object.
     * 
     * @param other the object to compare this Contract against
     * @return <code>true<code> if and only if the Contract are equal based on their contents.
     * @see java.lang.Object#equals(Object)
     */
	public boolean equals(Object other) {
	    if (this == other) return true;
	    if (other == null) return false; 
	    if (getClass() != other.getClass()) return false;
	    return id.equals(((Contract)other).id);
    } 

	/**
	 * Returns the hash code value for this Contract.
	 *
	 * @return the hash code value for this Contract.
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return id.hashCode();
	}
   
    /**
     * Returns a string representation of this Contract
     *
     * @return a string representation of this Contract
     * @see java.lang.Object#toString()
     */
    public String toString() {
       return name;
    }
}
