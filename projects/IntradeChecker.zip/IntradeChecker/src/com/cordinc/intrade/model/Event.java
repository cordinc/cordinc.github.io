//Copyright (c) 2009 Charles Cordingley (cordinc.com)
//Licensed under MIT License (see license.txt)

package com.cordinc.intrade.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Model class represent an Intrade Event.
 * 
 * @author cordinc
 */
public class Event {
	private static final long DAY_MS = 24l*60l*60l*1000l;
	
	private final Date endDate;
	private final String id;
	private final String name;
	private final String group;
	private final Collection<Contract> contracts = new ArrayList<Contract>();
	private final ReadWriteLock lock = new ReentrantReadWriteLock();
	
	/**
	 * Construct the Intrade event.
	 * @param id the Intrade id code of this event.
	 * @param name the name of this event.
	 * @param group the description of the event group which contains this event (may be null).
	 * @param endDate the date this event expires
	 */
	public Event(String id, String name, String group, Date endDate) {
		this.id = id;
		this.name = name;
		this.group = group;
		this.endDate = endDate;
	}
	
	/**
	 * Adds the contracts in the given collection into this event.
	 * @param contracts a collection of the contracts to add.
	 */
	public void addContracts(Collection<Contract> contracts) {
		lock.writeLock().lock();
		this.contracts.addAll(contracts);
		lock.writeLock().unlock();
	}
	
	/**
	 * Returns a shallow copy of the contracts in this event.
	 * @return a shallow copy of the contracts in this event.
	 */
	public Collection<Contract> getContracts() {
		lock.readLock().lock();
		Collection<Contract> result = new ArrayList<Contract>(contracts);
		lock.readLock().unlock();
		return result;
	}

	/**
	 * Return the date this event expires.
	 * @return the date this event expires.
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * Returns the id code of this event.
	 * @return the id code of this event.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Returns the description of the event. This consists of the event group name (if present) and the event name.
	 * @return the description of the event
	 */
	public String getDescription() {
		return ((group!=null)?group+": ":"")+ name;
	}
	
	/**
	 * The number of whole days remaining until this event expires from the current time. 
	 * Can be negative.
	 * @return the number of whole days remaining until this event expires.
	 */
	public int daysRemaining() {
		return Math.round((endDate.getTime() - System.currentTimeMillis())/DAY_MS);
	}
	
	/**
     * Compares this Event to the specified object for equality. The result
     * is true if and only if the argument is not null and is a Event object
     * that has the same id as this object.
     * 
     * @param other the object to compare this Event against
     * @return <code>true<code> if and only if the Event are equal based on their contents.
     * @see java.lang.Object#equals(Object)
     */
	public boolean equals(Object other) {
	    if (this == other) return true;
	    if (other == null) return false; 
	    if (getClass() != other.getClass()) return false;
	    return id.equals(((Event)other).id);
    } 

	/**
	 * Returns the hash code value for this Event.
	 *
	 * @return the hash code value for this Event.
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return id.hashCode();
	}
   
    /**
     * Returns a string representation of this Event
     *
     * @return a string representation of this Event
     * @see java.lang.Object#toString()
     */
    public String toString() {
       return getDescription();
    }
}
