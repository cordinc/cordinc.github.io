// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.model;

/**
 * The state of the contract.
 * 
 * @author cordinc
 */
public enum ContractState {
	INITIALIZED("I"),
	OPEN("O"),
	PAUSED("P"),
	CLOSED("C"),
	EXPIRY("E"),
	SETTLED("S"),
	CANCELLED("X"),
	REVERSED("R");
	
	private final String code;
	
	private ContractState(String code) {
		this.code = code;
	}
	
	/** 
	 * Returns the Intrade one-letter code for this state.
	 * @return the Intrade one-letter code for this state.
	 */
	public String getCode() {
		return code;
	}
	
	/**
	 * Converts an Intrade one-letter code into a contract state.
	 * @param code The Intrade state code.
	 * @return the contract state matching the given code.
	 */
	public static ContractState parseCode(String code) {
		for (ContractState cs: ContractState.values()) {
			if (cs.code.equals(code)) {
				return cs;
			}
		}
		return null;
	}
}
