// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.model;

/**
 * An aggregated quote level for a contract. That is, this combines all the quotes at a particular price.
 * For example, if the second best quote is to buy 10 contracts at $45 and the tick size is $0.01, then the resulting 
 * ContractDepth has Side=BID, level=0, priceTicks=4500 (45/0.01) and quantity 10.
 * 
 * @author cordinc
 */
public class ContractDepth {
	
	private final Side side;
	private final int level;
	private final int priceTicks;
	private final int quantity;
	private final double tickSize;
	
	/**
	 * Construct the ContractDepth
	 * 
	 * @param side the side of the quote
	 * @param level the level of the quote, that is it is the level'th best quote on the given side. 0 is the best quote.
	 * @param priceTicks the number of price ticks in the price.
	 * @param quantity the quantity being offered at this price and side.
	 * @param tickSize the size of a price tick.
	 */
	public ContractDepth(Side side, int level, int priceTicks, int quantity, double tickSize) {
		this.side = side;
		this.level = level;
		this.priceTicks = priceTicks;
		this.quantity = quantity;
		this.tickSize = tickSize;
	}
	
	/**
	 * The price at this side and level. It is the product of the tick size and number of whole ticks. Be aware that
	 * numerical errors may be present in this value.
	 * @return the price at this side and level.
	 */
	public double price() {
		return tickSize*priceTicks;
	}
	
	/**
	 * The possible gross profit (not including fees) to be made on the contract to be made on the contract at this price.  
	 * @return the gross profit to be made on the contract.
	 */
	public double grossProfit() {
		return (side==Side.ASK)?100-price():price();
	}
	
	/**
	 * The possible net profit (including fees) to be made on the contract to be made on the contract at this price.  
	 * @return the net profit to be made on the contract.
	 */
	public double netProfit() {
		double profit = grossProfit();
		if (profit<5) {
			return profit - 1.3;
		} else {
			return profit - 1.4;
		}
	}
	
	/**
	 * The interest rate implied by the net profit on this contract if it expires in the given number of days. 
	 * @param daysRemaining the days until contract expiry.
	 * @return the interest rate implied by the net profit.
	 */
	public double implicitRate(int daysRemaining) {
    	double deflator = 365d/(daysRemaining+1);
		return Math.pow(1+(netProfit()/(100-grossProfit())), deflator) - 1;
	}
	
	/**
	 * The side of the quote. That is this to buy or sell the contract.
	 * @return the side of the quote.
	 */
	public Side getSide() {
		return side;
	}
	
	/**
	 * The size of each price tick.
	 * @return the size of each price tick.
	 */
	public double getTickSize() {
		return tickSize;
	}

	/**
	 * Returns the level of the quote. That is it is the level'th best quote on the given side. 0 is the best quote.
	 * @return the level of the quote
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * The number of price ticks in this price. Price is stored as whole ticks so if required numerical errors can be avoided.
	 * @return the number of price ticks in this price.
	 */
	public int getPriceTicks() {
		return priceTicks;
	}

	/**
	 * The quantity being offered at this price and side.
	 * @return the quantity being offered at this price and side.
	 */
	public int getQuantity() {
		return quantity;
	}
	
	/**
     * Compares this ContractDepth to the specified object for equality. The result
     * is true if and only if the argument is not null and is a ContractDepth object
     * that has the same internal values as this object.
     * 
     * @param other the object to compare this ContractDepth against
     * @return <code>true<code> if and only if the ContractDepth are equal based on their contents.
     * @see java.lang.Object#equals(Object)
     */
	public boolean equals(Object other) {
	    if (this == other) return true;
	    if (other == null) return false; 
	    if (getClass() != other.getClass()) return false;
	    ContractDepth otherDepth = (ContractDepth)other;
	    return level==otherDepth.level && side==otherDepth.side 
	    		&& quantity==otherDepth.quantity && priceTicks==otherDepth.priceTicks
	    		&& tickSize==otherDepth.tickSize;
    } 

	/**
	 * Returns the hash code value for this ContractDepth.
	 *
	 * @return the hash code value for this ContractDepth.
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return (37*level)+side.ordinal();
	}
   
    /**
     * Returns a string representation of this ContractDepth
     *
     * @return a string representation of this ContractDepth
     * @see java.lang.Object#toString()
     */
    public String toString() {
       return ""+level+": "+side+" "+quantity+"@"+price();
    }
}
