// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade.model;

/**
 * Whether the offer is to buy or sell a contract.
 * @author cordinc
 */
public enum Side {
	BID, // Offering to buy contract
	ASK  // Offering to sell contract
}
