// Copyright (c) 2009 Charles Cordingley (cordinc.com)
// Licensed under MIT License (see license.txt)

package com.cordinc.intrade;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.cordinc.intrade.load.EventLoader;
import com.cordinc.intrade.model.Contract;
import com.cordinc.intrade.model.ContractDepth;
import com.cordinc.intrade.model.Event;
import com.cordinc.intrade.model.Side;

public class IntradeChecker {
	
	private static final NumberFormat NF = new DecimalFormat("0.##");
	
	private final int daysToGo;
	private final double priceLimit;
	private final double rateThreshold;
		
	public static void main(String[] args) {
		if (args.length != 3) {
			System.out.println("Usage: IntradeChecker <remaining days> <profit limit> <rate threshold>");
		} else {
			new IntradeChecker(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2])).process();
		}
	}
	
	public IntradeChecker(int daysToGo, double priceLimit, double rateThreshold) {
		this.daysToGo = daysToGo;
		this.priceLimit = priceLimit;
		this.rateThreshold = rateThreshold;
	}
	
	private void process() {
		Collection<Event> events = new EventLoader().get(daysToGo);
		Map<Integer, Map<Double, List<String>>> results = new TreeMap<Integer, Map<Double, List<String>>>();
		        
        for (Event e: events) {
	       	for (Contract c: e.getContracts()) {
	            checkDepth(c.getAskDepth(0), c, e, results);
	    		checkDepth(c.getBidDepth(0), c, e, results);             
	        }
        }
        
        for (Map.Entry<Integer, Map<Double, List<String>>> e: results.entrySet()) {
        	System.out.println(e.getKey().toString()+ " day(s) remaining");
        	for (Map.Entry<Double, List<String>> f: e.getValue().entrySet()) {
        		for (String l: f.getValue()) {
        			System.out.println("  "+NF.format(f.getKey())+ "%: "+l);
        		}
        	}
        }
	}
	
	private void checkDepth(ContractDepth depth, Contract c, Event e, Map<Integer, Map<Double, List<String>>> results) {
		if (depth!=null) {
			int daysRemaining = e.daysRemaining();
        	double profit = depth.grossProfit();
        	if (profit<priceLimit) {
        		double rate = depth.implicitRate(daysRemaining);
        		if (rate > rateThreshold) {
        			addEntry(results, daysRemaining, rate, (depth.getSide()==Side.ASK?"Buy ":"Sell ")+depth.getQuantity()+"@"+NF.format(depth.price())
        				+" "+e.getDescription()+": "+c.getName());
        		}
        	}
        }
	}
	
	private void addEntry(Map<Integer, Map<Double, List<String>>> lines, int remainingDays, double rate, String line) {
		Map<Double, List<String>> dayLines = lines.get(remainingDays);
		if (dayLines==null) {
			dayLines = new TreeMap<Double, List<String>>();
			lines.put(remainingDays, dayLines);
		}
		List<String> rateLines = dayLines.get(rate);
		if (rateLines==null) {
			rateLines = new ArrayList<String>();
			dayLines.put(rate, rateLines);
		}
		rateLines.add(line);
	}
}
