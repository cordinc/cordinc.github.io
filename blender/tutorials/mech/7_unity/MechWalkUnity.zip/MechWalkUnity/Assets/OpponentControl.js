class OpponentControl extends MechControl {

var speed = 40;
var rotateSpeed = 20;
private var laserShow = 0;

function Start() {
  InitLaser();
  animation["Walkcycle"].speed = 0.75; 
}

function Update () {
  if (!isAlive) {
	ClearLaser();
	animation.Stop();
	return;
  }
  animation.Play("Walkcycle");
  transform.Rotate(0, Time.deltaTime * rotateSpeed, 0);
  var directionForward = transform.InverseTransformDirection(transform.forward);
  transform.Translate(directionForward * Time.deltaTime * speed/2);
  if (WouldHit()) {
    FireLaser();
	laserShow = 2;
  } else {
	if (laserShow>0) {
	  laserShow-= Time.deltaTime;
	} else {
      ClearLaser();
	}
  }
}

function WouldHit():boolean {
  var hit : RaycastHit;
  if (Physics.Raycast ( transform.position+transform.forward*laserStart, transform.forward, hit, laserRange)) {
     return hit.collider.tag.Equals("Player");
  } else {
     return false;
  }
}

function OnGUI() {
  if (!isAlive) {
    var res = Screen.currentResolution;
    GUI.Label(Rect((Screen.width/2) - 25 , (Screen.height/2) - 10 , 80, 20), "You Win!");
  }
}

}