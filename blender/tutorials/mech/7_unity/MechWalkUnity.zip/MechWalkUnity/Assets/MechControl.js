class MechControl extends MonoBehaviour {

protected var isAlive = true;
protected var laserStart = 4;
protected var laserRange = 50.0+laserStart;
protected var laserOffset = Vector3(0,15,0);
private var laser : LineRenderer;
var laserMaterial : Material;

function InitLaser() {
  laser = this.gameObject.AddComponent(LineRenderer);
  laser.SetWidth(0.5, 0.5);
  laser.SetVertexCount(2);
  laser.material = laserMaterial;
  laser.renderer.enabled = false;
  laser.useWorldSpace = true;
}

function ClearLaser() {
  if (laser.renderer.enabled) {
    laser.renderer.enabled = false;
  }
}

function FireLaser() {
  laser.SetPosition(0, transform.position+transform.forward*laserStart+laserOffset);
  laser.SetPosition(1, transform.position+transform.forward*laserRange+laserOffset);
  laser.renderer.enabled = true;
  Hit();
}

function Hit() {
  var hit : RaycastHit;
  if (Physics.Raycast ( transform.position+transform.forward*laserStart, transform.forward, hit, laserRange)) {
     hit.transform.SendMessage("LaserStrike",gameObject, SendMessageOptions.DontRequireReceiver);
  } 
}

function LaserStrike(source : GameObject) {
  if (isAlive) {
    transform.Rotate(180, 0, 0);
	transform.Translate(0, -collider.size.y, 0);
  }
  isAlive = false;
}

}