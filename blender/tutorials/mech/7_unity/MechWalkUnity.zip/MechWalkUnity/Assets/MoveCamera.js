function Update () {
  if (Input.GetKey (KeyCode.Z)) {
    transform.RotateAround (Vector3.zero, Vector3.up, 20 * Time.deltaTime);
  } else if (Input.GetKey (KeyCode.X)) {
    transform.RotateAround (Vector3.zero, Vector3.up, -20 * Time.deltaTime);
  }
}