class PlayerControl extends MechControl {
    
static var max_speed = 100.0;
static var min_speed = 0.0;

var rotateSpeed = 2000;
private var speed = min_speed;

function Start() {
  InitLaser();
}

function Update () {
  if (!isAlive) {
	ClearLaser();
	animation.Stop();
	return;
  }
  
  if (Input.GetKey (KeyCode.UpArrow) && speed<max_speed) {
    speed++;
  } else if (Input.GetKey (KeyCode.DownArrow) && speed>min_speed) {
	speed--;
  }
  
  var directionForward = transform.InverseTransformDirection(transform.forward);
  if (speed>0) {
    animation["Walkcycle"].speed = speed/50; 
	animation.Play("Walkcycle");
    transform.Rotate(0, Input.GetAxis("Horizontal") * Time.deltaTime * rotateSpeed / speed, 0);
	transform.Translate(directionForward * Time.deltaTime * speed/4);
  } else {
	animation.Stop();
  }
  
  if (Input.GetKey(KeyCode.Space)) {
    FireLaser();
  } else {
    ClearLaser();
  }
}

function OnGUI() {
  GUI.Label(Rect(50, 50, 100, 20), "Speed: "+speed);
  if (!isAlive) {
    var res = Screen.currentResolution;
    GUI.Label(Rect((Screen.width/2) - 30 , (Screen.height/2) - 10 , 90, 20), "You Lose!");
  }
}

}