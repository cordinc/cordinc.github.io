#include "MechWalkTest.h"

//-------------------------------------------------------------------------------------
MechWalkTest::MechWalkTest(void):
	mSpeed(0.0f),
	mCameraAngle(0.0f),
	mOrbitRadius(150.0f),
	mOrbitIncrementRadians(Ogre::Math::PI/250),
	mMechDirection(Ogre::Math::PI/2),
	mPlaneSize(200),
	mSpeedChange(0.25)
{
}
//-------------------------------------------------------------------------------------
MechWalkTest::~MechWalkTest(void)
{
}

void MechWalkTest::createViewports(void)
{
    // Create one viewport, entire window
    Ogre::Viewport* vp = mWindow->addViewport(mCamera);
    vp->setBackgroundColour(Ogre::ColourValue(0,0,0));
    // Alter the camera aspect ratio to match the viewport
    mCamera->setAspectRatio(Ogre::Real(vp->getActualWidth()) / Ogre::Real(vp->getActualHeight()));    
}

void MechWalkTest::createCamera(void)
{
    // create the camera
    mCamera = mSceneMgr->createCamera("PlayerCam");
    // set its position, direction  
	mCamera->setPosition(Ogre::Vector3(mOrbitRadius*Ogre::Math::Cos(mCameraAngle),200,mOrbitRadius*Ogre::Math::Sin(mCameraAngle)));
    mCamera->lookAt(Ogre::Vector3(0,0,0));
    // set the near clip distance
    mCamera->setNearClipDistance(5);
 
    mCameraMan = new OgreBites::SdkCameraMan(mCamera);   // create a default camera controller
}

//-------------------------------------------------------------------------------------
void MechWalkTest::createScene(void)
{

	Ogre::MaterialManager::getSingleton().setDefaultTextureFiltering(Ogre::TFO_ANISOTROPIC);
    Ogre::MaterialManager::getSingleton().setDefaultAnisotropy(16);

    Ogre::Entity* mechEntity = mSceneMgr->createEntity("Mech", "Mech.mesh");	
	Ogre::AxisAlignedBox box = mechEntity->getBoundingBox();
    mMechNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
    mMechNode->attachObject(mechEntity);
	mMechNode->setScale(0.8f, 0.8f, 0.8f);
	//mMechNode->showBoundingBox(true);
	//Ogre::LogManager::getSingleton().logMessage("asdfdsf "+Ogre::StringConverter::toString(box.getSize().y));

	mMechNode->setPosition(0, -box.getCorner(Ogre::AxisAlignedBox::FAR_LEFT_BOTTOM).y, 0);
	mechEntity->setCastShadows(true);
	mAnimationState = mechEntity->getAnimationState("Walkcycle");
	mAnimationState->setLoop(true);
 
    // Set ambient light
    mSceneMgr->setAmbientLight(Ogre::ColourValue(0.0, 0.0, 0.0));
	mSceneMgr->setShadowTechnique(Ogre::SHADOWTYPE_STENCIL_ADDITIVE);
	addSpotlight("spotLight1", 250.0, 0);
	addSpotlight("spotLight2", 0, -250.0);
	addSpotlight("spotLight3", 0, 250.0);
	addSpotlight("spotLight4", -250.0, 0);

	Ogre::Plane plane(Ogre::Vector3::UNIT_Y, 0);
 
    Ogre::MeshManager::getSingleton().createPlane("ground", Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
        plane, mPlaneSize, mPlaneSize, 20, 20, true, 1, 5, 5, Ogre::Vector3::UNIT_Z);
 
    Ogre::Entity* entGround = mSceneMgr->createEntity("GroundEntity", "ground");
    mSceneMgr->getRootSceneNode()->createChildSceneNode()->attachObject(entGround);
 
    entGround->setMaterialName("Examples/BumpyMetal");
    entGround->setCastShadows(false);
}

void MechWalkTest::addSpotlight(const Ogre::String name, const Ogre::Real xPos, const Ogre::Real zPos) 
{
	Ogre::Light* spotLight = mSceneMgr->createLight(name);
    spotLight->setType(Ogre::Light::LT_SPOTLIGHT);
    spotLight->setDiffuseColour(1.0, 1.0, 1.0);
    spotLight->setSpecularColour(1.0, 1.0, 1.0);
	spotLight->setDirection(-xPos/xPos, -1, -zPos/zPos);
    spotLight->setPosition(xPos, 250.0, zPos);
	spotLight->setAttenuation(500.0f, 0.5f, 0.007f, 0.0f);
	spotLight->setSpotlightRange(Ogre::Degree(180), Ogre::Degree(180));
}

bool MechWalkTest::processUnbufferedInput(const Ogre::FrameEvent& evt)
{
	if (mTrayMgr->isDialogVisible()) return true;   // don't process any more keys if dialog is up

	if (mKeyboard->isKeyDown(OIS::KC_Z)) {
		if (mCameraAngle==2*Ogre::Math::PI) mCameraAngle = 0;
		mCameraAngle+=mOrbitIncrementRadians;
		mCamera->setPosition(Ogre::Vector3(mOrbitRadius*Ogre::Math::Cos(mCameraAngle),200,mOrbitRadius*Ogre::Math::Sin(mCameraAngle)));
		mCamera->yaw(Ogre::Radian(-mOrbitIncrementRadians));
	} else if (mKeyboard->isKeyDown(OIS::KC_X)) {		
		if (mCameraAngle==0) mCameraAngle = 2*Ogre::Math::PI;
		mCameraAngle-=mOrbitIncrementRadians;
        mCamera->setPosition(Ogre::Vector3(mOrbitRadius*Ogre::Math::Cos(mCameraAngle),200,mOrbitRadius*Ogre::Math::Sin(mCameraAngle)));
		mCamera->yaw(Ogre::Radian(mOrbitIncrementRadians));
    }

	if (mKeyboard->isKeyDown(OIS::KC_UP)) {
		if (mSpeed<10) mSpeed+=mSpeedChange;
	} else if (mKeyboard->isKeyDown(OIS::KC_DOWN)) {
		if (mSpeed>0) mSpeed-=mSpeedChange;
	}

	if (mSpeed>0) {
		if (mKeyboard->isKeyDown(OIS::KC_RIGHT)) {
			mMechDirection += mOrbitIncrementRadians;
			mMechNode->yaw(Ogre::Radian(-mOrbitIncrementRadians));
		} else if (mKeyboard->isKeyDown(OIS::KC_LEFT))	{
			mMechDirection -= mOrbitIncrementRadians;
			mMechNode->yaw(Ogre::Radian(mOrbitIncrementRadians));
		}
	}

	if (mKeyboard->isKeyDown(OIS::KC_ESCAPE)) {
        mShutDown = true;
    }
    return true;
}

void MechWalkTest::createFrameListener(void)
{
	BaseApplication::createFrameListener();

	Ogre::StringVector items;
    items.push_back("Speed");
    mSpeedPanel = mTrayMgr->createParamsPanel(OgreBites::TL_NONE, "", 200, items);
    mTrayMgr->moveWidgetToTray(mSpeedPanel, OgreBites::TL_TOPLEFT, 0);
    mSpeedPanel->show();	
	mTrayMgr->toggleAdvancedFrameStats();
}

bool MechWalkTest::keyPressed( const OIS::KeyEvent &arg )
{
	if (arg.key == OIS::KC_SYSRQ) {
        mWindow->writeContentsToTimestampedFile("screenshot", ".jpg");
    }
	return true; //BaseApplication::keyPressed(arg);
}

//-------------------------------------------------------------------------------------
bool MechWalkTest::frameRenderingQueued(const Ogre::FrameEvent& evt)
{
	// jumping is because of bad modelling
	if (mSpeed>0) {
		mAnimationState->setEnabled(true);
		mAnimationState->addTime(evt.timeSinceLastFrame * mSpeed/5);
		mMechNode->translate(Ogre::Vector3(Ogre::Math::Cos(mMechDirection),0,Ogre::Math::Sin(mMechDirection)) * mSpeed * evt.timeSinceLastFrame * 2.5);
		checkBounds(mMechNode->getPosition());
	} else {
		mAnimationState->setEnabled(false);
	}
	
	mSpeedPanel->setParamValue(0, Ogre::StringConverter::toString(mSpeed));
    bool ret = BaseApplication::frameRenderingQueued(evt);
	if (!processUnbufferedInput(evt)) return false;
    return ret;
}

void MechWalkTest::checkBounds(const Ogre::Vector3& position)
{
	Ogre::Vector3 newPosition(position.x, position.y, position.z);
	bool changed = false;
	if (position.x>mPlaneSize/2){
		newPosition.x = mPlaneSize/2;
		changed = true;
	} else if (position.x<-mPlaneSize/2) {
		newPosition.x = -mPlaneSize/2;
		changed = true;
	}

	if (position.z>mPlaneSize/2){
		newPosition.z = mPlaneSize/2;
		changed = true;
	} else if (position.z<-mPlaneSize/2) {
		newPosition.z = -mPlaneSize/2;
		changed = true;
	}

	if (changed) {
		mMechNode->setPosition(newPosition);
		mAnimationState->setEnabled(false);
		mMechNode->yaw(Ogre::Radian(Ogre::Math::PI));
		mMechDirection = fmod(mMechDirection+Ogre::Math::PI, 2*Ogre::Math::PI);
		mSpeed = 0;
	}
}


#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
    INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT )
#else
    int main(int argc, char *argv[])
#endif
    {
        // Create application object
        MechWalkTest app;

        try {
            app.go();
        } catch( Ogre::Exception& e ) {
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
            MessageBox( NULL, e.getFullDescription().c_str(), "An exception has occured!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
#else
            std::cerr << "An exception has occured: " <<
                e.getFullDescription().c_str() << std::endl;
#endif
        }

        return 0;
    }

#ifdef __cplusplus
}
#endif
