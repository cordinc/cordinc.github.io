
#ifndef __MechWalkTest_h_
#define __MechWalkTest_h_

#include "BaseApplication.h"
#include <stdio.h>
#include <math.h>

class MechWalkTest : public BaseApplication
{
public:
    MechWalkTest(void);
    virtual ~MechWalkTest(void);

protected:
	virtual void createFrameListener(void);
	virtual bool frameRenderingQueued(const Ogre::FrameEvent& evt);	
    virtual void createScene(void);
	virtual void createCamera(void);
	virtual void createViewports(void);
	virtual bool keyPressed(const OIS::KeyEvent &arg);

	Ogre::Real mOrbitRadius;
	Ogre::Real mOrbitIncrementRadians;
	Ogre::Real mCameraAngle;
	Ogre::Real mMechDirection;  
	Ogre::Real mSpeed;
	Ogre::Real mSpeedChange;
	Ogre::Real mPlaneSize;
	Ogre::SceneNode* mMechNode;
	OgreBites::ParamsPanel* mSpeedPanel;
	Ogre::AnimationState *mAnimationState; // The current animation state of the object	 

private:
	bool processUnbufferedInput(const Ogre::FrameEvent& evt);
	void checkBounds(const Ogre::Vector3& position);
	void addSpotlight(const Ogre::String name, const Ogre::Real xPos, const Ogre::Real zPos);
};

#endif // #ifndef __MechWalkTest_h_
